package com.example.formacao

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.core.content.FileProvider
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.example.formacao.database.MinhaBaseDados
import com.example.formacao.databinding.DetalhesBinding
import com.example.formacao.models.Transacao
import com.example.formacao.models.Utilizador
import com.example.formacao.notifications.NotificationWorker
import com.example.formacao.utils.showToast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class DetalhesPageActivity : AppCompatActivity() {

    companion object {
        private const val PREFS_NAME = "FinlyAppPrefs"
        private const val KEY_EMAIL = "EMAIL"
    }

    private lateinit var binding: DetalhesBinding

    private var isTransacaoMode = false

    // Dados do Utilizador
    private var userId: Int = -1
    private var userNameStr: String = ""
    private var emailStr: String = ""
    private var phoneStr: String = ""
    private var senhaStr: String = ""
    private var fotoUriStr: String? = null

    // Dados da Transação
    private var transId: Int = -1
    private var transItem: String = ""
    private var transValor: Double = 0.0
    private var transData: String = ""
    private var transTipo: String = ""
    private var transCat: String = ""
    private var transMes: String = ""
    private var transAno: Int = 2026
    private var transIsRecorrente: Boolean = false
    private var transParcelasRestantes: Int = 0
    private var transParcelasTotais: Int = 0
    private var transStatus: Boolean = false

    private var latestTmpUri: Uri? = null

    private val pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { processarNovaFoto(it) }
    }

    private val takePictureLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success: Boolean ->
        if (success) {
            latestTmpUri?.let { processarNovaFoto(it) }
        }
    }

    private val requestCameraPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
        if (isGranted) {
            abrirCamara()
        } else {
            showToast("Permissão de câmara negada")
        }
    }

    private val requestNotificationPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
        if (isGranted) {
            ativarNotificacoes()
        } else {
            binding.switchNotifications.isChecked = false
            showToast("Permissão de notificação negada")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = DetalhesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isTransacaoMode = intent.getBooleanExtra("isTransactionDetail", false)

        if (isTransacaoMode) {
            configurarParaTransacao()
        } else {
            configurarParaPerfil()
        }

        configurarCliques()

        // Ajustar Insets para que o cabeçalho e botões respeitem as barras do sistema
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            
            // Adiciona padding no topo do cabeçalho de forma natural
            binding.headerView.updatePadding(top = systemBars.top)
            
            // Sobe o conteúdo do fundo para não ficar atrás dos botões nativos
            binding.root.updatePadding(bottom = systemBars.bottom)
            insets
        }
    }

    private fun configurarParaTransacao() {
        transId = intent.getIntExtra("id", -1)
        transItem = intent.getStringExtra("item") ?: "Item"
        transValor = intent.getDoubleExtra("valor", 0.0)
        transData = intent.getStringExtra("vencimento") ?: ""
        transTipo = intent.getStringExtra("tipo") ?: "DESPESA"
        transCat = intent.getStringExtra("categoria") ?: "Geral"
        transMes = intent.getStringExtra("mes") ?: ""
        transAno = intent.getIntExtra("ano", 2026)
        transIsRecorrente = intent.getBooleanExtra("isRecorrente", false)
        transParcelasRestantes = intent.getIntExtra("parcelasRestantes", 0)
        transParcelasTotais = intent.getIntExtra("parcelasTotais", 0)
        transStatus = intent.getBooleanExtra("status", false)

        atualizarUITransacao()

        binding.llTransacaoButtons.visibility = View.VISIBLE
        binding.llPerfilButtons.visibility = View.GONE
    }

    private fun atualizarUITransacao() {
        binding.userName.text = transItem
        binding.tvUserInitial.text = transItem.takeIf { it.isNotEmpty() }?.take(1)?.uppercase(Locale.getDefault()) ?: "T"
        binding.tvEmailDetail.text = getString(R.string.valor_label, transValor, transTipo)
        binding.tvPhoneDetail.text = getString(R.string.data_label, transData)
        binding.tvExtraDetail.text = getString(R.string.categoria_mes_label, transCat, transMes)
        binding.tvExtraDetail.visibility = View.VISIBLE
    }

    private fun configurarParaPerfil() {
        userId = intent.getIntExtra("id", -1)
        userNameStr = intent.getStringExtra("name") ?: "Utilizador"
        emailStr = intent.getStringExtra("email") ?: ""
        phoneStr = intent.getStringExtra("phone") ?: ""
        senhaStr = intent.getStringExtra("senha") ?: ""
        fotoUriStr = intent.getStringExtra("foto")

        atualizarUIPerfil()

        val isOwnProfile = intent.getBooleanExtra("isOwnProfile", false)
        if (isOwnProfile) {
            binding.cardEditPhoto.visibility = View.VISIBLE
            binding.cardSettings.visibility = View.VISIBLE
            configurarConfiguracoes()
        }

        binding.llPerfilButtons.visibility = View.VISIBLE
        binding.llTransacaoButtons.visibility = View.GONE
    }

    private fun atualizarUIPerfil() {
        binding.userName.text = userNameStr
        binding.tvEmailDetail.text = emailStr
        binding.tvPhoneDetail.text = phoneStr.ifEmpty { "Telemóvel não definido" }

        if (!fotoUriStr.isNullOrEmpty()) {
            binding.ivUserProfile.visibility = View.VISIBLE
            binding.tvUserInitial.visibility = View.GONE
            // Forçar refresh limpando a imagem antes de definir a nova
            binding.ivUserProfile.setImageURI(null)
            binding.ivUserProfile.setImageURI(Uri.parse(fotoUriStr))
        } else {
            binding.ivUserProfile.visibility = View.GONE
            binding.tvUserInitial.visibility = View.VISIBLE
            binding.tvUserInitial.text = if (userNameStr.isNotEmpty()) userNameStr.take(1).uppercase(Locale.getDefault()) else "U"
        }

        binding.tvExtraDetail.visibility = View.GONE
    }

    private fun configurarCliques() {
        // Perfil
        binding.btnVerContactos.setOnClickListener { finish() }
        binding.avatarCard.setOnClickListener { if (intent.getBooleanExtra("isOwnProfile", false)) mostrarDialogEscolhaFoto() }
        binding.cardEditPhoto.setOnClickListener { if (intent.getBooleanExtra("isOwnProfile", false)) mostrarDialogEscolhaFoto() }
        binding.btnEditarPerfil.setOnClickListener { irParaEdicaoPerfil() }
        binding.btnVoltarLogin.setOnClickListener { mostrarDialogSair() }
        binding.btnExcluirConta.setOnClickListener { confirmarExclusaoConta() }

        // Transação
        binding.btnVoltarPlanilha.setOnClickListener { finish() }
        binding.btnEditarTransacao.setOnClickListener {
            val intent = Intent(this, RegistoActivity::class.java)
            intent.putExtra("isEditTransaction", true)
            intent.putExtra("id", transId)
            intent.putExtra("item", transItem)
            intent.putExtra("valor", transValor)
            intent.putExtra("vencimento", transData)
            intent.putExtra("tipo", transTipo)
            intent.putExtra("status", transStatus)
            intent.putExtra("mes", transMes)
            intent.putExtra("ano", transAno)
            intent.putExtra("isRecorrente", transIsRecorrente)
            intent.putExtra("parcelasRestantes", transParcelasRestantes)
            intent.putExtra("parcelasTotais", transParcelasTotais)
            startActivity(intent)
        }
        binding.btnEliminarTransacao.setOnClickListener { confirmarEliminacaoTransacao() }
    }

    private fun irParaEdicaoPerfil() {
        if (intent.getBooleanExtra("isOwnProfile", false)) {
            val intent = Intent(this, RegistoActivity::class.java)
            intent.putExtra("isUserEdit", true)
            intent.putExtra("id", userId)
            intent.putExtra("name", userNameStr)
            intent.putExtra("email", emailStr)
            intent.putExtra("phone", phoneStr)
            intent.putExtra("senha", senhaStr)
            intent.putExtra("foto", fotoUriStr)
            startActivity(intent)
        }
    }

    private fun configurarConfiguracoes() {
        val sharedPref = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)

        // Notificações
        binding.switchNotifications.isChecked = sharedPref.getBoolean("notifications_active", false)
        binding.switchNotifications.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                verificarPermissaoNotificacao()
            } else {
                sharedPref.edit { putBoolean("notifications_active", false) }
                cancelarNotificacoes()
            }
        }

        // Modo Escuro
        val isDarkMode = sharedPref.getBoolean("dark_mode_manual", false)
        binding.switchDarkMode.isChecked = isDarkMode
        atualizarTextoModoEscuro(isDarkMode)

        binding.switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            sharedPref.edit { putBoolean("dark_mode_manual", isChecked) }
            val mode = if (isChecked) AppCompatDelegate.MODE_NIGHT_YES else AppCompatDelegate.MODE_NIGHT_NO
            AppCompatDelegate.setDefaultNightMode(mode)

            atualizarTextoModoEscuro(isChecked)
            val msg = if (isChecked) "Modo Escuro Ativado" else "Modo Claro Ativado"
            showToast(msg)
        }
    }

    private fun atualizarTextoModoEscuro(isDark: Boolean) {
        binding.tvDarkModeLabel.text = if (isDark) "Ativar Modo Claro" else "Ativar Modo Escuro"
    }

    private fun verificarPermissaoNotificacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) {
                ativarNotificacoes()
            } else {
                requestNotificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            ativarNotificacoes()
        }
    }

    private fun ativarNotificacoes() {
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit { putBoolean("notifications_active", true) }
        agendarNotificacoes()
    }

    private fun agendarNotificacoes() {
        val workRequest = PeriodicWorkRequestBuilder<NotificationWorker>(24, java.util.concurrent.TimeUnit.HOURS)
            .addTag("expiry_notification")
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "due_date_check",
            ExistingPeriodicWorkPolicy.KEEP,
            workRequest
        )
        showToast("Lembretes agendados!")
    }

    private fun cancelarNotificacoes() {
        WorkManager.getInstance(this).cancelAllWorkByTag("expiry_notification")
        showToast("Lembretes desativados")
    }

    private fun mostrarDialogEscolhaFoto() {
        val options = arrayOf("Câmara", "Galeria", "Remover Foto")
        AlertDialog.Builder(this)
            .setTitle("Escolher foto de perfil")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> verificarPermissaoCamara()
                    1 -> pickImageLauncher.launch("image/*")
                    2 -> removerFotoPerfil()
                }
            }
            .show()
    }

    private fun verificarPermissaoCamara() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            abrirCamara()
        } else {
            requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun removerFotoPerfil() {
        fotoUriStr = null
        atualizarUIPerfil()

        lifecycleScope.launch(Dispatchers.IO) {
            val db = MinhaBaseDados.getDatabase(this@DetalhesPageActivity)
            val utilizador = Utilizador(
                id = userId,
                nome = userNameStr,
                email = emailStr,
                telemovel = phoneStr,
                senha = senhaStr,
                fotoUri = null
            )
            db.utilizadorDao().atualizarUtilizador(utilizador)
            withContext(Dispatchers.Main) {
                showToast("Foto removida")
            }
        }
    }

    private fun abrirCamara() {
        lifecycleScope.launch {
            try {
                val uri = getTmpFileUri()
                latestTmpUri = uri

                // Conceder permissão explicitamente para evitar avisos/erros em APIs novas
                val cameraIntent = Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE)
                val resolvedIntentActivities = packageManager.queryIntentActivities(cameraIntent, PackageManager.MATCH_DEFAULT_ONLY)
                for (resolvedIntentInfo in resolvedIntentActivities) {
                    val targetPackageName = resolvedIntentInfo.activityInfo.packageName
                    grantUriPermission(targetPackageName, uri, Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }

                takePictureLauncher.launch(uri)
            } catch (_: Exception) {
            showToast("Erro ao preparar câmara")
        }
        }
    }

    private fun getTmpFileUri(): Uri {
        val tmpFile = File(cacheDir, "perfil_tmp.png").apply {
            if (exists()) delete()
            createNewFile()
        }
        val authority = "$packageName.fileprovider"
        return FileProvider.getUriForFile(applicationContext, authority, tmpFile)
    }

    private fun processarNovaFoto(uri: Uri) {
        fotoUriStr = uri.toString()

        // Persistir permissão se for da galeria
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {}

        // Atualizar UI imediatamente
        atualizarUIPerfil()

        // Guardar no Banco de Dados imediatamente em segundo plano
        lifecycleScope.launch(Dispatchers.IO) {
            val db = MinhaBaseDados.getDatabase(this@DetalhesPageActivity)
            val utilizador = Utilizador(
                id = userId,
                nome = userNameStr,
                email = emailStr,
                telemovel = phoneStr,
                senha = senhaStr,
                fotoUri = fotoUriStr
            )
            db.utilizadorDao().atualizarUtilizador(utilizador)
            withContext(Dispatchers.Main) {
                // Confirmar que os dados locais estão sincronizados
                recarregarDadosPerfil()
            }
        }
    }

    private fun confirmarEliminacaoTransacao() {
        if (transIsRecorrente) {
            val options = arrayOf(
                "Apagar apenas este mês (Mantém recorrência futura)",
                "Apagar este e todos os meses futuros (Interrompe recorrência)"
            )
            AlertDialog.Builder(this)
                .setTitle("Eliminar Item Recorrente")
                .setMessage("Esta transação é recorrente. Como deseja apagá-la?\n(Os meses anteriores não serão afetados)")
                .setItems(options) { _, which ->
                    when (which) {
                        0 -> executarEliminacaoSimples()
                        1 -> executarEliminacaoFutura()
                    }
                }
                .setNegativeButton("Cancelar", null)
                .show()
        } else {
            AlertDialog.Builder(this)
                .setTitle("Eliminar")
                .setMessage("Deseja apagar '$transItem'?")
                .setPositiveButton("Sim") { _, _ -> executarEliminacaoSimples() }
                .setNegativeButton("Não", null)
                .show()
        }
    }

    private fun executarEliminacaoSimples() {
        lifecycleScope.launch(Dispatchers.IO) {
            val db = MinhaBaseDados.getDatabase(this@DetalhesPageActivity)
            val trans = Transacao(
                id = transId, item = transItem, valor = transValor, vencimento = transData,
                tipo = transTipo, donoEmail = emailStr, mes = transMes, ano = transAno,
                categoria = transCat, status = transStatus, isRecorrente = transIsRecorrente,
                parcelasRestantes = transParcelasRestantes, parcelasTotais = transParcelasTotais
            )
            db.utilizadorDao().apagarTransacao(trans)
            withContext(Dispatchers.Main) {
                finish()
            }
        }
    }

    private fun executarEliminacaoFutura() {
        lifecycleScope.launch(Dispatchers.IO) {
            val db = MinhaBaseDados.getDatabase(this@DetalhesPageActivity)
            val dao = db.utilizadorDao()
            
            // 1. Obter todas as transações do dono
            val todas = dao.obterTransacoesPorDono(emailStr)
            
            // 2. Filtrar apenas as que têm o mesmo nome e são do presente/futuro
            val mesesLista = listOf("Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro")
            val indexAtual = mesesLista.indexOf(transMes)
            
            val paraApagar = todas.filter {
                it.item.equals(transItem, ignoreCase = true) &&
                ((it.ano > transAno) || (it.ano == transAno && mesesLista.indexOf(it.mes) >= indexAtual))
            }
            
            // 3. Apagar uma a uma
            paraApagar.forEach { dao.apagarTransacao(it) }

            withContext(Dispatchers.Main) {
                showToast("Itens futuros removidos!")
                finish()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (isTransacaoMode) {
            recarregarDadosTransacao()
        } else {
            recarregarDadosPerfil()
        }
    }

    private fun recarregarDadosTransacao() {
        if (transId == -1) return

        lifecycleScope.launch(Dispatchers.IO) {
            val db = MinhaBaseDados.getDatabase(this@DetalhesPageActivity)
            val transacao = db.utilizadorDao().obterTransacaoPorId(transId)
            withContext(Dispatchers.Main) {
                transacao?.let {
                    transItem = it.item
                    transValor = it.valor
                    transData = it.vencimento
                    transTipo = it.tipo
                    transCat = it.categoria
                    transMes = it.mes
                    transAno = it.ano
                    transIsRecorrente = it.isRecorrente
                    transParcelasRestantes = it.parcelasRestantes
                    transParcelasTotais = it.parcelasTotais
                    transStatus = it.status
                    atualizarUITransacao()
                }
            }
        }
    }

    private fun recarregarDadosPerfil() {
        val currentEmail = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_EMAIL, "") ?: ""
        if (currentEmail.isEmpty()) return

        lifecycleScope.launch(Dispatchers.IO) {
            val db = MinhaBaseDados.getDatabase(this@DetalhesPageActivity)
            val utilizador = db.utilizadorDao().buscarPorEmail(currentEmail)
            withContext(Dispatchers.Main) {
                utilizador?.let {
                    userId = it.id
                    userNameStr = it.nome
                    emailStr = it.email
                    phoneStr = it.telemovel
                    senhaStr = it.senha
                    fotoUriStr = it.fotoUri
                    atualizarUIPerfil()
                }
            }
        }
    }

    private fun mostrarDialogSair() {
        AlertDialog.Builder(this)
            .setTitle("Sair")
            .setMessage("Deseja terminar a sessão?")
            .setPositiveButton("Sim") { _, _ ->
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit { 
                    remove("EMAIL")
                    remove("NAME")
                    remove("LAST_LOGIN_TIMESTAMP")
                }
                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .setNegativeButton("Não", null)
            .show()
    }

    private fun confirmarExclusaoConta() {
        AlertDialog.Builder(this)
            .setTitle("Eliminar Registo")
            .setMessage("Tem a certeza que deseja apagar a sua conta? Todas as suas transações serão eliminadas permanentemente.")
            .setPositiveButton("Sim, Eliminar") { _, _ ->
                lifecycleScope.launch(Dispatchers.IO) {
                    val db = MinhaBaseDados.getDatabase(this@DetalhesPageActivity)
                    val dao = db.utilizadorDao()

                    // 1. Apagar transações
                    dao.apagarTodasTransacoesDoDono(emailStr)

                    // 2. Apagar utilizador
                    val utilizador = Utilizador(id = userId, nome = userNameStr, email = emailStr, telemovel = phoneStr, senha = senhaStr, fotoUri = fotoUriStr)
                    dao.apagarUtilizador(utilizador)

                    withContext(Dispatchers.Main) {
                        // 3. Limpar preferências e sair
                        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit { clear() }
                        val intent = Intent(this@DetalhesPageActivity, LoginActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                        showToast("Conta eliminada com sucesso")
                        finish()
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
