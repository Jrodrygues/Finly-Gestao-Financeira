package com.example.formacao.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.formacao.R
import com.example.formacao.models.Transacao

class TransacaoAdapter(
    private var lista: List<Transacao>,
    private val onItemClick: (Transacao) -> Unit, // Clique na linha (Vai para Detalhes)
    private val onToggleStatus: (Transacao) -> Unit
): RecyclerView.Adapter<TransacaoAdapter.TransacaoViewHolder>() {

    fun updateData(novaLista: List<Transacao>) {
        this.lista = novaLista
        notifyDataSetChanged()
    }

    class TransacaoViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val tvItem: TextView = view.findViewById(R.id.tvItem)
        val tvVencimento: TextView = view.findViewById(R.id.tvVencimento)
        val tvValor: TextView = view.findViewById(R.id.tvValor)
        val ivStatus: ImageView = view.findViewById(R.id.ivStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TransacaoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_transacao, parent, false)
        return TransacaoViewHolder(view)
    }

    override fun onBindViewHolder(holder: TransacaoViewHolder, position: Int) {
        val item = lista[position]

        // Lógica para mostrar parcelas (ex: 1/3)
        val textoExibicao = if (item.isRecorrente && item.parcelasTotais > 0) {
            val parcelaAtual = item.parcelasTotais - item.parcelasRestantes
            "${item.item} ($parcelaAtual/${item.parcelasTotais})"
        } else {
            item.item
        }

        holder.tvItem.text = textoExibicao
        holder.tvVencimento.text = item.vencimento
        holder.tvValor.text = String.format("%.2f €", item.valor)

        if (item.tipo == "DESPESA") {
            holder.tvValor.setTextColor(0xFFF44336.toInt())
        } else {
            holder.tvValor.setTextColor(0xFF4CAF50.toInt())
            // Removido o símbolo + conforme pedido
        }

        if (item.status) {
            holder.ivStatus.setImageResource(android.R.drawable.checkbox_on_background)
            holder.ivStatus.setColorFilter(0xFF009688.toInt())
        } else {
            holder.ivStatus.setImageResource(android.R.drawable.checkbox_off_background)
            holder.ivStatus.setColorFilter(0xFFBDBDBD.toInt())
        }

        // Clique na linha inteira para ver Detalhes (Onde estará Editar/Excluir)
        holder.itemView.setOnClickListener { onItemClick(item) }
        
        // Clique no ícone de status
        holder.ivStatus.setOnClickListener { onToggleStatus(item) }
    }

    override fun getItemCount() = lista.size
}
