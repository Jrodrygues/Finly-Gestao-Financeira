package com.example.formacao

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.Spannable
import android.text.SpannableString
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.View
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import com.example.formacao.adapters.TransacaoAdapter
import com.example.formacao.database.MinhaBaseDados
import com.example.formacao.databinding.HomeBinding
import com.example.formacao.models.Transacao
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var binding: HomeBinding
    private var todasTransacoes = listOf<Transacao>()
    private var mesFiltro: String? = null
    private var anoFiltro: Int = 2026
    
    private var adapter: TransacaoAdapter? = null
    
    private val meses = arrayOf("Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro")
    private val recurrenceMutex = Mutex()

    companion object {
        private const val PREFS_NAME = "FinlyAppPrefs"
        private const val KEY_EMAIL = "EMAIL"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = HomeBinding.inflate(layoutInflater)
        setContentView(binding.root)


        // Configurar LayoutManager no onCreate apenas uma vez
        binding.rvTransacoes.layoutManager = LinearLayoutManager(this)

        // Obter o mês e ano filtrado vindos do Resumo
        val cal = java.util.Calendar.getInstance()
        mesFiltro = intent.getStringExtra("MES_SELECIONADO") ?: meses[cal[java.util.Calendar.MONTH]]
        anoFiltro = intent.getIntExtra("ANO_SELECIONADO", cal[java.util.Calendar.YEAR])
        atualizarTituloMes()

        binding.btnMesAnterior.setOnClickListener { navegarMes(-1) }
        binding.btnMesProximo.setOnClickListener { navegarMes(1) }

        binding.fabAddTransacao.setOnClickListener {
            val intent = Intent(this, RegistoActivity::class.java)
            intent.putExtra("MES_ATUAL", mesFiltro)
            intent.putExtra("ANO_ATUAL", anoFiltro)
            startActivity(intent)
        }

        binding.tvMainTitle.setOnClickListener {
            finish()
        }

        binding.etSearch.addTextChangedListener(
            object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    filtrarLista(binding.tabFilter.selectedTabPosition)
                }

                override fun afterTextChanged(s: Editable?) {}
            },
        )

        binding.tabFilter.addOnTabSelectedListener(
            object : TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: TabLayout.Tab?) {
                    filtrarLista(tab?.position ?: 0)
                }

                override fun onTabUnselected(tab: TabLayout.Tab?) {}
                override fun onTabReselected(tab: TabLayout.Tab?) {}
            },
        )

        // Ajustar Insets para o cabeçalho e rodapé não ficarem tapados pelas barras do sistema
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            
            // Subir o rodapé (Saldo) para ficar acima dos botões nativos
            val bottomPadding = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 12f, resources.displayMetrics).toInt()
            binding.llSaldoFooter.updatePadding(bottom = systemBars.bottom + bottomPadding)
            
            // Empurrar o cabeçalho para baixo da barra de status (horas, bateria)
            binding.clHeader.updatePadding(top = systemBars.top)
            
            insets
        }
    }

    override fun onResume() {
        super.onResume()
        carregarLista()
    }


    private fun navegarMes(direcao: Int) {
        val indexAtual = meses.indexOf(mesFiltro)
        var novoIndex = indexAtual + direcao

        if (novoIndex < 0) {
            novoIndex = 11
            anoFiltro--
        } else if (novoIndex > 11) {
            novoIndex = 0
            anoFiltro++
        }

        mesFiltro = meses[novoIndex]
        atualizarTituloMes()
        carregarLista()

        // Sincronizar com o ecrã de resumo para quando voltar
        getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().apply {
            putString("ULTIMO_MES_SELECIONADO", mesFiltro)
            putInt("ULTIMO_ANO_SELECIONADO", anoFiltro)
            apply()
        }
    }

    private fun atualizarTituloMes() {
        binding.tvMainTitle.text = String.format(Locale.getDefault(), "%s %d", mesFiltro?.uppercase(Locale.getDefault()), anoFiltro)
    }

    private fun carregarLista() {
        val currentEmail = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_EMAIL, "") ?: ""

        lifecycleScope.launch(Dispatchers.IO) {
            val db = MinhaBaseDados.getDatabase(this@MainActivity)

            recurrenceMutex.withLock {
                mesFiltro?.let { processarRecorrencia(db, currentEmail, it, anoFiltro) }
            }

            val todasDoDono = db.utilizadorDao().obterTransacoesPorDono(currentEmail)

            val transacoesFiltradas = if (mesFiltro != null) {
                todasDoDono.filter { (it.mes == mesFiltro) && (it.ano == anoFiltro) }
            } else {
                todasDoDono
            }

            withContext(Dispatchers.Main) {
                todasTransacoes = transacoesFiltradas
                filtrarLista(binding.tabFilter.selectedTabPosition)
            }
        }
    }

    private fun filtrarLista(posicao: Int) {
        val query = binding.etSearch.text.toString().trim().lowercase()

        val filtrada = when (posicao) {
            1 -> todasTransacoes.filter { it.tipo == "DESPESA" }
            2 -> todasTransacoes.filter { it.tipo == "RENDA" }
            else -> todasTransacoes
        }.filter { it.item.lowercase().contains(query) }

        atualizarRecycler(filtrada)
        atualizarSaldoVisual(posicao)
    }

    private fun atualizarRecycler(lista: List<Transacao>) {
        if (adapter == null) {
            adapter = TransacaoAdapter(
                lista,
                onItemClick = { transacao ->
                    val intent = Intent(this@MainActivity, DetalhesPageActivity::class.java)
                    intent.putExtra("isTransactionDetail", true)
                    intent.putExtra("id", transacao.id)
                    intent.putExtra("item", transacao.item)
                    intent.putExtra("valor", transacao.valor)
                    intent.putExtra("vencimento", transacao.vencimento)
                    intent.putExtra("tipo", transacao.tipo)
                    intent.putExtra("status", transacao.status)
                    intent.putExtra("categoria", transacao.categoria)
                    intent.putExtra("mes", transacao.mes)
                    intent.putExtra("ano", transacao.ano)
                    intent.putExtra("isRecorrente", transacao.isRecorrente)
                    intent.putExtra("parcelasRestantes", transacao.parcelasRestantes)
                    intent.putExtra("parcelasTotais", transacao.parcelasTotais)
                    startActivity(intent)
                },
                onToggleStatus = { 
                    toggleStatusTransacao(it)
                }
            )
            binding.rvTransacoes.adapter = adapter
        } else {
            adapter?.updateData(lista)
        }
    }

    private fun atualizarSaldoVisual(posicaoTab: Int) {
        val rendaTotal = todasTransacoes.asSequence().filter { it.tipo == "RENDA" }.sumOf { it.valor }
        val despesaTotal = todasTransacoes.asSequence().filter { it.tipo == "DESPESA" }.sumOf { it.valor }
        val saldoFinal = rendaTotal - despesaTotal

        val colorPositivo = ContextCompat.getColor(this, R.color.colorPositive)
        val colorNegativo = ContextCompat.getColor(this, R.color.colorNegative)

        when (posicaoTab) {
            1 -> {
                setSaldoColorido(getString(R.string.total_despesas), despesaTotal, colorNegativo)
                binding.tvDetalheSaldo.visibility = View.GONE
            }
            2 -> {
                setSaldoColorido(getString(R.string.total_rendas), rendaTotal, colorPositivo)
                binding.tvDetalheSaldo.visibility = View.GONE
            }
            else -> {
                val corSaldo = if (saldoFinal >= 0) colorPositivo else colorNegativo
                setSaldoColorido(getString(R.string.saldo_final_label), saldoFinal, corSaldo)
                binding.tvDetalheSaldo.text = String.format(Locale.getDefault(), "Rendas: %.2f € | Despesas: %.2f €", rendaTotal, despesaTotal)
                binding.tvDetalheSaldo.visibility = View.VISIBLE
            }
        }
    }

    private fun setSaldoColorido(prefixo: String, valor: Double, corValor: Int) {
        val valorTexto = String.format(Locale.getDefault(), "%.2f €", valor)
        val fullText = prefixo + valorTexto
        val spannable = SpannableString(fullText)

        val start = prefixo.length
        val end = fullText.length
        spannable.setSpan(ForegroundColorSpan(corValor), start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)

        binding.tvSaldoTotal.text = spannable
    }

    private fun toggleStatusTransacao(transacao: Transacao) {
        val index = todasTransacoes.indexOfFirst { it.id == transacao.id }
        if (index != -1) {
            val novaTransacao = transacao.copy(status = !transacao.status)
            val novaLista = todasTransacoes.toMutableList()
            novaLista[index] = novaTransacao
            todasTransacoes = novaLista
            filtrarLista(binding.tabFilter.selectedTabPosition)

            lifecycleScope.launch(Dispatchers.IO) {
                val db = MinhaBaseDados.getDatabase(this@MainActivity)
                db.utilizadorDao().atualizarTransacao(novaTransacao)
            }
        }
    }

    private fun processarRecorrencia(db: MinhaBaseDados, email: String, mesAlvo: String, anoAlvo: Int) {
        val recorrentes = db.utilizadorDao().obterTransacoesRecorrentes(email)
        val transacoesAtuaisNoMomento = db.utilizadorDao().obterTransacoesPorMes(email, mesAlvo, anoAlvo)
        val nomesExistentes = transacoesAtuaisNoMomento.asSequence().map { it.item.trim().lowercase() }.toSet()

        val itensModelos = recorrentes.filter { it.donoEmail == email }
            .sortedWith(compareBy({ it.ano }, { meses.indexOf(it.mes) }))
            .reversed()
            .distinctBy { it.item.trim().lowercase() }

        itensModelos.forEach { rec ->
            val nomeFormatado = rec.item.trim().lowercase()
            if (!nomesExistentes.contains(nomeFormatado)) {
                val mesRecIndex = meses.indexOf(rec.mes)
                val mesAlvoIndex = meses.indexOf(mesAlvo)
                val isAnterior = (rec.ano < anoAlvo) || ((rec.ano == anoAlvo) && (mesRecIndex < mesAlvoIndex))

                if (isAnterior && ((rec.parcelasRestantes > 0) || (rec.parcelasRestantes == -1))) {
                    val diaOriginal = rec.vencimento.split("/").firstOrNull() ?: "01"
                    val mesIndex = meses.indexOf(mesAlvo)
                    val novoVencimento = String.format(Locale.getDefault(), "%s/%02d", diaOriginal, mesIndex + 1)
                    val nova = rec.copy(
                        id = 0,
                        mes = mesAlvo,
                        ano = anoAlvo,
                        vencimento = novoVencimento,
                        status = false,
                        isRecorrente = true,
                        parcelasRestantes = if (rec.parcelasRestantes > 0) rec.parcelasRestantes - 1 else -1,
                        parcelasTotais = rec.parcelasTotais
                    )
                    db.utilizadorDao().inserirTransacao(nova)
                }
            }
        }
    }
}
