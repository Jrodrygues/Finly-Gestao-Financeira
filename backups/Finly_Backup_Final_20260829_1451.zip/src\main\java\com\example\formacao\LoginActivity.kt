package com.example.formacao

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.core.content.edit
import androidx.lifecycle.lifecycleScope
import com.example.formacao.database.MinhaBaseDados
import com.example.formacao.databinding.LoginBinding
import com.example.formacao.utils.showToast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: LoginBinding

    companion object {
        private const val PREFS_NAME = "FinlyAppPrefs"
        private const val KEY_NAME = "NAME"
        private const val KEY_EMAIL = "EMAIL"
        private const val KEY_LAST_LOGIN = "LAST_LOGIN_TIMESTAMP"
        private const val SESSION_TIMEOUT = 15L * 24 * 60 * 60 * 1000 // 15 Dias
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = LoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        verificarSessaoAtiva()

        binding.loginbtn.setOnClickListener {
            fazerLogin()
        }

        binding.btnRegistar.setOnClickListener {
            val intent = Intent(this, RegistoActivity::class.java)
            intent.putExtra("isNewUser", true)
            startActivity(intent)
        }

        binding.btnConvidado.setOnClickListener {
            entrarComoConvidado()
        }

        // Carregar e-mail lembrado se existir
        carregarEmailLembrado()
    }

    private fun carregarEmailLembrado() {
        val sharedPref = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        val emailLembrado = sharedPref.getString("EMAIL_LEMBRADO", "")
        if (!emailLembrado.isNullOrEmpty()) {
            binding.emailText.setText(emailLembrado)
            binding.cbLembrarEmail.isChecked = true
        }
    }

    override fun onResume() {
        super.onResume()
        // Verificar se há um e-mail acabado de registar para preencher
        val sharedPref = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        val tempEmail = sharedPref.getString("TEMP_EMAIL", "")
        if (!tempEmail.isNullOrEmpty()) {
            binding.emailText.setText(tempEmail)
            // Limpar para não preencher sempre
            sharedPref.edit { remove("TEMP_EMAIL") }
        }
    }

    private fun verificarSessaoAtiva() {
        val sharedPref = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        val lastLogin = sharedPref.getLong(KEY_LAST_LOGIN, 0L)
        val currentTime = System.currentTimeMillis()
        val email = sharedPref.getString(KEY_EMAIL, "") ?: ""

        if ((lastLogin != 0L) && (currentTime - lastLogin < SESSION_TIMEOUT) && email.isNotEmpty() && (email != "CONVIDADO")) {
            lifecycleScope.launch(Dispatchers.IO) {
                val db = MinhaBaseDados.getDatabase(applicationContext)
                val user = db.utilizadorDao().buscarPorEmail(email)
                withContext(Dispatchers.Main) {
                    if (user != null) {
                        prosseguirParaApp()
                    } else {
                        sharedPref.edit { clear() }
                    }
                }
            }
        }
    }

    private fun fazerLogin() {
        val email = binding.emailText.text.toString().trim()
        val senha = binding.senhaText.text.toString().trim()

        if (email.isEmpty() || senha.isEmpty()) {
            showToast("Introduza o e-mail e a palavra-passe")
            return
        }

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val db = MinhaBaseDados.getDatabase(this@LoginActivity)
                val utilizador = db.utilizadorDao().validarLogin(email, senha)

                withContext(Dispatchers.Main) {
                    if (utilizador != null) {
                        val sharedPref = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
                        
                        sharedPref.edit {
                            // Guardar a sessão
                            putString(KEY_NAME, utilizador.nome)
                            putString(KEY_EMAIL, email)
                            putLong(KEY_LAST_LOGIN, System.currentTimeMillis())
                            
                            // Guardar ou limpar o e-mail lembrado de forma independente
                            if (binding.cbLembrarEmail.isChecked) {
                                putString("EMAIL_LEMBRADO", email)
                            } else {
                                remove("EMAIL_LEMBRADO")
                            }
                        }
                        prosseguirParaApp()
                    } else {
                        showToast("E-mail ou palavra-passe incorretos!", isLong = true)
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showToast("Erro ao aceder à base de dados: ${e.message}", isLong = true)
                }
            }
        }
    }

    private fun entrarComoConvidado() {
        AlertDialog.Builder(this)
            .setTitle("Aviso de Convidado")
            .setMessage("Como convidado, os seus dados são locais. Deseja continuar?")
            .setPositiveButton("Sim") { _, _ ->
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit().apply {
                    putString(KEY_EMAIL, "CONVIDADO")
                    putLong(KEY_LAST_LOGIN, System.currentTimeMillis())
                    apply()
                }
                prosseguirParaApp()
            }
            .setNegativeButton("Voltar", null)
            .show()
    }

    private fun prosseguirParaApp() {
        // Agora vamos direto para o Resumo Mensal (ResumoActivity)
        startActivity(Intent(this, ResumoActivity::class.java))
        finish()
    }
}
