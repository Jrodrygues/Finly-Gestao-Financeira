package com.example.formacao.`interface`

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.formacao.models.MetaPoupanca
import com.example.formacao.models.Transacao
import com.example.formacao.models.Utilizador

@Dao
interface UtilizadorDAO {
    // --- Lógica de Metas ---
    @Insert(onConflict = androidx.room.OnConflictStrategy.REPLACE)
    fun salvarMeta(meta: MetaPoupanca)

    @Query("SELECT * FROM tabela_metas WHERE donoEmail = :email AND mes = :mes AND ano = :ano LIMIT 1")
    fun obterMetaPorMes(email: String, mes: String, ano: Int): MetaPoupanca?

    // --- Lógica de Utilizadores (Login/Contas) ---
    @Insert
    fun insertUtilizador(utilizador: Utilizador)

    @Update
    fun atualizarUtilizador(utilizador: Utilizador)

    @Query("SELECT * FROM Tabela_utilizadores WHERE email = :email AND senha = :senha LIMIT 1")
    fun validarLogin(email: String, senha: String): Utilizador?

    @Query("SELECT * FROM Tabela_utilizadores WHERE email = :email LIMIT 1")
    fun buscarPorEmail(email: String): Utilizador?

    @Query("SELECT * FROM Tabela_utilizadores")
    fun obterTodosUtilizadores(): List<Utilizador>

    @Delete
    fun apagarUtilizador(utilizador: Utilizador)

    @Query("DELETE FROM tabela_transacoes WHERE donoEmail = :email")
    fun apagarTodasTransacoesDoDono(email: String)


    // --- Lógica de Transações (Planilha Financeira) ---
    @Insert
    fun inserirTransacao(transacao: Transacao)

    @Update
    fun atualizarTransacao(transacao: Transacao)

    @Delete
    fun apagarTransacao(transacao: Transacao)

    @Query("SELECT * FROM tabela_transacoes WHERE donoEmail = :email ORDER BY id ASC")
    fun obterTransacoesPorDono(email: String): List<Transacao>

    @Query("SELECT * FROM tabela_transacoes WHERE donoEmail = :email AND mes = :mes AND ano = :ano")
    fun obterTransacoesPorMes(email: String, mes: String, ano: Int): List<Transacao>

    @Query("SELECT * FROM tabela_transacoes WHERE donoEmail = :email AND isRecorrente = 1")
    fun obterTransacoesRecorrentes(email: String): List<Transacao>
    @Query("SELECT * FROM tabela_transacoes WHERE id = :id LIMIT 1")
    fun obterTransacaoPorId(id: Int): Transacao?
}
