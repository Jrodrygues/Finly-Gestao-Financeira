package com.example.formacao.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tabela_metas")
data class MetaPoupanca(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val mes: String,
    val ano: Int,
    val valor: Double,
    val donoEmail: String
)
