package com.example.formacao.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.formacao.`interface`.UtilizadorDAO
import com.example.formacao.models.MetaPoupanca
import com.example.formacao.models.Transacao
import com.example.formacao.models.Utilizador

@Database(entities = [Utilizador::class, Transacao::class, MetaPoupanca::class], version = 15) // Versão 15: Criada tabela de Metas separada por mês
abstract class MinhaBaseDados: RoomDatabase() {
    abstract fun utilizadorDao(): UtilizadorDAO

    companion object  {
        private var INSTANCE: MinhaBaseDados? = null

        fun getDatabase(context: Context): MinhaBaseDados {
            return INSTANCE ?: synchronized(this){
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MinhaBaseDados::class.java,
                    "minha_base_dados"
                )
                    .fallbackToDestructiveMigration()
                    .build()

                INSTANCE = instance
                instance
            }
        }
    }
}
