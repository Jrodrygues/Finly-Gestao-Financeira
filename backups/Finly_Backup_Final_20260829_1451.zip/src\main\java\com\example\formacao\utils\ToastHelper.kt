package com.example.formacao.utils

import android.content.Context
import android.view.LayoutInflater
import android.widget.TextView
import android.widget.Toast
import com.example.formacao.R

object ToastHelper {
    fun showCustomToast(context: Context, message: String, isLong: Boolean = false) {
        val inflater = LayoutInflater.from(context)
        val layout = inflater.inflate(R.layout.layout_custom_toast, null)

        val text: TextView = layout.findViewById(R.id.tvToastMessage)
        text.text = message

        with(Toast(context)) {
            duration = if (isLong) Toast.LENGTH_LONG else Toast.LENGTH_SHORT
            view = layout
            show()
        }
    }
}

fun Context.showToast(message: String, isLong: Boolean = false) {
    ToastHelper.showCustomToast(this, message, isLong)
}
