package com.example.formacao

import android.content.ContentValues
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.enableEdgeToEdge
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.core.graphics.scale
import androidx.core.net.toUri
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import com.example.formacao.database.MinhaBaseDados
import com.example.formacao.databinding.ActivityResumoBinding
import com.example.formacao.models.MetaPoupanca
import com.example.formacao.models.Transacao
import com.example.formacao.utils.showToast
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Locale

class ResumoActivity : AppCompatActivity() {
    private lateinit var binding: ActivityResumoBinding
    private val meses = arrayOf("Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro")
    private val anos = (2020..(Calendar.getInstance()[Calendar.YEAR] + 10)).toList().toTypedArray()
    
    private val recurrenceMutex = Mutex()
    private var lastLoadedMonth: String? = null
    private var lastLoadedYear: Int? = null
    private var metaAtual: Double = 0.0

    companion object {
        private const val PREFS_NAME = "FinlyAppPrefs"
        private const val KEY_LAST_MONTH = "ULTIMO_MES_SELECIONADO"
        private const val KEY_LAST_YEAR = "ULTIMO_ANO_SELECIONADO"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityResumoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        configurarSpinners()
        configurarDrawer()
        setupBackNavigation()

        // Ajustar Insets para o cabeçalho e rodapé respeitarem as barras do sistema
        ViewCompat.setOnApplyWindowInsetsListener(binding.drawerLayout) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            
            // Adiciona padding no topo do cabeçalho de forma natural
            binding.viewHeader.updatePadding(top = systemBars.top)
            
            // Garante que o conteúdo no fundo, suba para não ficar atrás dos botões nativos
            v.updatePadding(bottom = systemBars.bottom)
            insets
        }

        binding.btnVerDetalhes.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("MES_SELECIONADO", binding.spinnerMes.selectedItem.toString())
            intent.putExtra("ANO_SELECIONADO", binding.spinnerAno.selectedItem as Int)
            startActivity(intent)
        }

        binding.btnMenu.setOnClickListener {
            binding.drawerLayout.openDrawer(androidx.core.view.GravityCompat.START)
        }

        binding.btnExportarPDF.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                exportarParaPDF()
            } else {
                showToast("Exportação PDF requer Android 10+")
            }
        }

        binding.btnDefinirMeta.setOnClickListener {
            mostrarDialogDefinirMeta()
        }
    }

    private fun mostrarDialogDefinirMeta() {
        val input = android.widget.EditText(this)
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        input.setText(metaAtual.toString())

        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Meta de Poupança")
            .setMessage("Quanto deseja poupar em ${binding.spinnerMes.selectedItem}?")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val novaMeta = input.text.toString().toDoubleOrNull() ?: 0.0
                salvarMeta(novaMeta)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun salvarMeta(valor: Double) {
        val email = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString("EMAIL", "") ?: ""
        val mesSel = binding.spinnerMes.selectedItem.toString()
        val anoSel = binding.spinnerAno.selectedItem as Int
        
        lifecycleScope.launch(Dispatchers.IO) {
            val db = MinhaBaseDados.getDatabase(this@ResumoActivity)
            val dao = db.utilizadorDao()
            
            // Tentar encontrar meta existente para atualizar ou criar uma.
            val metaExistente = dao.obterMetaPorMes(email, mesSel, anoSel)
            val metaObj = metaExistente?.copy(valor = valor)
                ?: MetaPoupanca(mes = mesSel, ano = anoSel, valor = valor, donoEmail = email)
            
            dao.salvarMeta(metaObj)
            
            withContext(Dispatchers.Main) {
                carregarDados(mesSel, anoSel)
                showToast("Meta guardada para $mesSel!")
            }
        }
    }

    private fun configurarDrawer() {
        val headerView = binding.navigationView.getHeaderView(0)
        val tvNome = headerView.findViewById<android.widget.TextView>(R.id.nav_header_name)
        val tvEmail = headerView.findViewById<android.widget.TextView>(R.id.nav_header_email)
        val tvInitial = headerView.findViewById<android.widget.TextView>(R.id.nav_header_initial)
        val ivFoto = headerView.findViewById<android.widget.ImageView>(R.id.nav_header_image)

        val email = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString("EMAIL", "") ?: ""

        lifecycleScope.launch(Dispatchers.IO) {
            val db = MinhaBaseDados.getDatabase(this@ResumoActivity)
            val utilizador = db.utilizadorDao().buscarPorEmail(email.trim())

            withContext(Dispatchers.Main) {
                if (utilizador != null) {
                    tvNome.text = utilizador.nome
                    tvEmail.text = utilizador.email
                    if (!utilizador.fotoUri.isNullOrEmpty()) {
                        ivFoto.visibility = View.VISIBLE
                        tvInitial.visibility = View.GONE
                        ivFoto.setImageURI(utilizador.fotoUri.toUri())
                    } else {
                        ivFoto.visibility = View.GONE
                        tvInitial.visibility = View.VISIBLE
                        tvInitial.text = utilizador.nome.take(1).uppercase()
                    }
                }
            }
        }

        binding.navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_resumo -> { }
                R.id.nav_planilha -> {
                    binding.btnVerDetalhes.performClick()
                }
                R.id.nav_perfil -> {
                    irParaMeuPerfil()
                }
                R.id.nav_guia -> {
                    startActivity(Intent(this@ResumoActivity, GuiaActivity::class.java))
                }
                R.id.nav_exportar -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        exportarParaPDF()
                    } else {
                        showToast("Exportação PDF requer Android 10+")
                    }
                }
                R.id.nav_sair -> {
                    mostrarDialogSair()
                }
            }
            binding.drawerLayout.closeDrawer(androidx.core.view.GravityCompat.START)
            true
        }
    }

    private fun mostrarDialogSair() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Sair")
            .setMessage("Deseja terminar a sessão?")
            .setPositiveButton("Sim") { _, _ ->
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit { 
                    remove("EMAIL")
                    remove("NAME")
                    remove("LAST_LOGIN_TIMESTAMP")
                }
                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .setNegativeButton("Não", null)
            .show()
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun exportarParaPDF() {
        val pdfDocument = PdfDocument()
        val paint = Paint()
        val titlePaint = Paint()

        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        val logoBitmap = android.graphics.BitmapFactory.decodeResource(resources, R.drawable.ic_logo_full)
        if (logoBitmap != null) {
            val scaledLogo = logoBitmap.scale(100, 100, filter = true)
            canvas.drawBitmap(scaledLogo, 450f, 20f, null)
        }

        titlePaint.textSize = 24f
        titlePaint.isFakeBoldText = true
        titlePaint.color = ContextCompat.getColor(this, R.color.colorAccent)
        canvas.drawText(getString(R.string.pdf_titulo), 40f, 60f, titlePaint)

        paint.textSize = 14f
        val mes = binding.spinnerMes.selectedItem.toString()
        val ano = binding.spinnerAno.selectedItem.toString()
        
        paint.isFakeBoldText = true
        canvas.drawText(getString(R.string.pdf_periodo, mes, ano), 40f, 100f, paint)
        
        paint.isFakeBoldText = false
        val startY = 140f
        val lineSpacing = 30f
        
        canvas.drawText(getString(R.string.pdf_renda_total, binding.tvTotalRenda.text), 40f, startY, paint)
        canvas.drawText(getString(R.string.pdf_despesa_total, binding.tvTotalDespesas.text), 40f, startY + lineSpacing, paint)
        canvas.drawText(getString(R.string.pdf_poupanca_total, binding.tvTotalPoupanca.text), 40f, startY + (lineSpacing * 2), paint)
        canvas.drawText(getString(R.string.pdf_meta_definida, metaAtual), 40f, startY + (lineSpacing * 3), paint)

        paint.textSize = 18f
        paint.isFakeBoldText = true
        canvas.drawText(getString(R.string.pdf_saldo_final, binding.tvSaldoFinal.text), 40f, startY + (lineSpacing * 5), paint)

        pdfDocument.finishPage(page)

        val nomeFicheiro = "Relatorio_${mes}_$ano.pdf"
        try {
            val resolver = contentResolver
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, nomeFicheiro)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { outputStream ->
                    pdfDocument.writeTo(outputStream)
                }
                showToast("Relatório salvo em Downloads!", isLong = true)
            }
        } catch (_: Exception) {
            showToast("Erro ao gerar PDF")
        } finally {
            pdfDocument.close()
        }
    }

    override fun onResume() {
        super.onResume()
        prosseguirComCarregamento()
    }

    private fun prosseguirComCarregamento() {
        val mesAtual = binding.spinnerMes.selectedItem?.toString() ?: meses[0]
        val anoAtual = binding.spinnerAno.selectedItem as? Int ?: anos[0]
        carregarDados(mesAtual, anoAtual)
        refreshDrawerHeader()
    }

    private fun refreshDrawerHeader() {
        val headerView = binding.navigationView.getHeaderView(0)
        val tvNome = headerView.findViewById<android.widget.TextView>(R.id.nav_header_name)
        val tvEmail = headerView.findViewById<android.widget.TextView>(R.id.nav_header_email)
        val tvInitial = headerView.findViewById<android.widget.TextView>(R.id.nav_header_initial)
        val ivFoto = headerView.findViewById<android.widget.ImageView>(R.id.nav_header_image)

        val email = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString("EMAIL", "") ?: ""

        lifecycleScope.launch(Dispatchers.IO) {
            val db = MinhaBaseDados.getDatabase(this@ResumoActivity)
            val utilizador = db.utilizadorDao().buscarPorEmail(email.trim())

            withContext(Dispatchers.Main) {
                if (utilizador != null) {
                    tvNome.text = utilizador.nome
                    tvEmail.text = utilizador.email
                    if (!utilizador.fotoUri.isNullOrEmpty()) {
                        ivFoto.visibility = View.VISIBLE
                        tvInitial.visibility = View.GONE
                        ivFoto.setImageURI(utilizador.fotoUri.toUri())
                    } else {
                        ivFoto.visibility = View.GONE
                        tvInitial.visibility = View.VISIBLE
                        tvInitial.text = utilizador.nome.take(1).uppercase()
                    }
                }
            }
        }
    }

    private fun irParaMeuPerfil() {
        val email = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString("EMAIL", "") ?: ""

        lifecycleScope.launch(Dispatchers.IO) {
            val db = MinhaBaseDados.getDatabase(this@ResumoActivity)
            val utilizador = db.utilizadorDao().buscarPorEmail(email.trim()) ?: db.utilizadorDao().obterTodosUtilizadores().find { it.email.trim() == email.trim() }

            withContext(Dispatchers.Main) {
                if (utilizador != null) {
                    val intent = Intent(this@ResumoActivity, DetalhesPageActivity::class.java)
                    intent.putExtra("isOwnProfile", true)
                    intent.putExtra("id", utilizador.id)
                    intent.putExtra("name", utilizador.nome)
                    intent.putExtra("email", utilizador.email)
                    intent.putExtra("phone", utilizador.telemovel)
                    intent.putExtra("senha", utilizador.senha)
                    intent.putExtra("foto", utilizador.fotoUri)
                    startActivity(intent)
                } else if (email == "CONVIDADO") {
                    showToast(getString(R.string.toast_convidado_perfil))
                } else {
                    showToast("A carregar perfil... Tente novamente.")
                }
            }
        }
    }

    private fun configurarSpinners() {
        val adapterMes = ArrayAdapter(this, android.R.layout.simple_spinner_item, meses)
        adapterMes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerMes.adapter = adapterMes

        val adapterAno = ArrayAdapter(this, android.R.layout.simple_spinner_item, anos)
        adapterAno.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerAno.adapter = adapterAno

        val sharedPref = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        val ultimoMesSalvo = sharedPref.getString(KEY_LAST_MONTH, null)
        val ultimoAnoSalvo = sharedPref.getInt(KEY_LAST_YEAR, 0)
        val cal = Calendar.getInstance()
        
        if (ultimoMesSalvo != null) {
            val index = meses.indexOf(ultimoMesSalvo)
            if (index != -1) binding.spinnerMes.setSelection(index)
        } else {
            binding.spinnerMes.setSelection(cal[Calendar.MONTH])
        }

        if (ultimoAnoSalvo != 0) {
            val index = anos.indexOf(ultimoAnoSalvo)
            if (index != -1) binding.spinnerAno.setSelection(index)
        } else {
            val index = anos.indexOf(cal[Calendar.YEAR])
            if (index != -1) binding.spinnerAno.setSelection(index)
        }

        val itemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val mesSel = binding.spinnerMes.selectedItem.toString()
                val anoSel = binding.spinnerAno.selectedItem as Int
                if (lastLoadedMonth == mesSel && lastLoadedYear == anoSel) return
                
                sharedPref.edit {
                    putString(KEY_LAST_MONTH, mesSel)
                    putInt(KEY_LAST_YEAR, anoSel)
                }
                carregarDados(mesSel, anoSel)
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        binding.spinnerMes.onItemSelectedListener = itemSelectedListener
        binding.spinnerAno.onItemSelectedListener = itemSelectedListener
    }

    private fun carregarDados(mesSelecionado: String, anoSelecionado: Int) {
        val email = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString("EMAIL", "") ?: ""
        lastLoadedMonth = mesSelecionado
        lastLoadedYear = anoSelecionado

        lifecycleScope.launch(Dispatchers.IO) {
            val db = MinhaBaseDados.getDatabase(this@ResumoActivity)
            recurrenceMutex.withLock {
                processarRecorrencia(db, email, mesSelecionado, anoSelecionado)
            }

            // BUSCAR META ESPECÍFICA DO MÊS
            val metaObj = db.utilizadorDao().obterMetaPorMes(email, mesSelecionado, anoSelecionado)
            metaAtual = metaObj?.valor ?: 0.0

            val transacoes = db.utilizadorDao().obterTransacoesPorMes(email, mesSelecionado, anoSelecionado)
            val totalRenda = transacoes.asSequence().filter { it.tipo == "RENDA" }.sumOf { it.valor }
            val totalDespesas = transacoes.asSequence().filter { it.tipo == "DESPESA" }.sumOf { it.valor }
            val totalPoupanca = transacoes.asSequence().filter { it.categoria == "Poupança" }.sumOf { it.valor }
            val totalExterior = transacoes.asSequence().filter { it.categoria == "Exterior" }.sumOf { it.valor }
            
            val saldo = totalRenda - totalDespesas
            val percentagemGasta = if (totalRenda > 0) (totalDespesas / totalRenda * 100).toInt() else 0

            withContext(Dispatchers.Main) {
                atualizarInterface(totalRenda, totalDespesas, totalPoupanca, totalExterior, saldo, percentagemGasta)
                configurarGrafico(transacoes)
                atualizarBarraMeta(totalPoupanca)
            }
        }
    }

    private fun atualizarBarraMeta(valorPoupado: Double) {
        binding.tvMetaValor.text = String.format(Locale.getDefault(), "%.2f €", metaAtual)
        
        if (metaAtual > 0) {
            val progresso = ((valorPoupado / metaAtual) * 100).toInt().coerceAtMost(100)
            binding.pbMetaPoupanca.progress = progresso
            binding.tvMetaStatus.text = getString(R.string.poupado_label, valorPoupado, progresso)
            
            if (progresso >= 100) {
                binding.tvMetaStatus.setTextColor(ContextCompat.getColor(this, R.color.colorPositive))
                binding.tvMetaStatus.text = getString(R.string.meta_atingida)
            } else {
                binding.tvMetaStatus.setTextColor(ContextCompat.getColor(this, R.color.textColorSecondary))
            }
        } else {
            binding.pbMetaPoupanca.progress = 0
            binding.tvMetaStatus.text = getString(R.string.meta_definir_aviso)
            binding.tvMetaStatus.setTextColor(ContextCompat.getColor(this, R.color.textColorSecondary))
        }
    }

    private fun configurarGrafico(transacoes: List<Transacao>) {
        val despesas = transacoes.filter { it.tipo == "DESPESA" }
        val gastosPorCategoria = despesas.groupBy { it.categoria }
            .mapValues { it.value.sumOf { t -> t.valor }.toFloat() }

        if (gastosPorCategoria.isEmpty()) {
            binding.pieChart.visibility = View.GONE
            return
        }
        binding.pieChart.visibility = View.VISIBLE

        val entries = gastosPorCategoria.map { PieEntry(it.value, it.key) }
        val dataSet = PieDataSet(entries, "")
        dataSet.colors = ColorTemplate.MATERIAL_COLORS.toList()
        dataSet.valueTextSize = 14f
        dataSet.valueTextColor = ContextCompat.getColor(this, R.color.textColorPrimary)

        val pieData = PieData(dataSet)
        binding.pieChart.data = pieData
        binding.pieChart.description.isEnabled = false
        binding.pieChart.centerText = "Gastos"
        binding.pieChart.setCenterTextSize(18f)
        binding.pieChart.setCenterTextColor(ContextCompat.getColor(this, R.color.textColorPrimary))
        binding.pieChart.legend.textColor = ContextCompat.getColor(this, R.color.textColorPrimary)
        binding.pieChart.setHoleColor(0)
        binding.pieChart.animateY(1000)
        binding.pieChart.invalidate()
    }

    private fun atualizarInterface(renda: Double, despesa: Double, poupanca: Double, exterior: Double, saldo: Double, percent: Int) {
        val colorPositivo = ContextCompat.getColor(this, R.color.colorPositive)
        val colorNegativo = ContextCompat.getColor(this, R.color.colorNegative)
        val colorPadrao = ContextCompat.getColor(this, R.color.textColorPrimary)

        binding.tvTotalRenda.text = String.format(Locale.getDefault(), "%.2f €", renda)
        binding.tvTotalRenda.setTextColor(colorPositivo)

        binding.tvTotalDespesas.text = String.format(Locale.getDefault(), "%.2f €", despesa)
        binding.tvTotalDespesas.setTextColor(colorNegativo)

        binding.tvTotalPoupanca.text = String.format(Locale.getDefault(), "%.2f €", poupanca)
        binding.tvTotalPoupanca.setTextColor(colorPadrao)
        
        binding.tvTotalBrasil.text = String.format(Locale.getDefault(), "%.2f €", exterior)
        binding.tvTotalBrasil.setTextColor(colorPadrao)
        
        binding.tvSaldoFinal.text = String.format(Locale.getDefault(), "%.2f €", saldo)
        binding.tvPercentValue.text = String.format(Locale.getDefault(), "%d%%", percent)
        binding.tvSpentValue.text = String.format(Locale.getDefault(), "%.2f €", despesa)
        
        binding.tvSaldoFinal.setTextColor(if (saldo < 0) colorNegativo else colorPositivo)
    }

    private fun processarRecorrencia(db: MinhaBaseDados, email: String, mesAlvo: String, anoAlvo: Int) {
        val recorrentes = db.utilizadorDao().obterTransacoesRecorrentes(email)
        val transacoesAtuaisNoMomento = db.utilizadorDao().obterTransacoesPorMes(email, mesAlvo, anoAlvo)
        val nomesExistentes = transacoesAtuaisNoMomento.asSequence().map { it.item.trim().lowercase() }.toSet()

        val itensModelos = recorrentes.filter { it.donoEmail == email }
            .sortedWith(compareBy({ it.ano }, { meses.indexOf(it.mes) }))
            .reversed()
            .distinctBy { it.item.trim().lowercase() }

        itensModelos.forEach { rec ->
            val nomeFormatado = rec.item.trim().lowercase()
            if (!nomesExistentes.contains(nomeFormatado)) {
                val mesRecIndex = meses.indexOf(rec.mes)
                val mesAlvoIndex = meses.indexOf(mesAlvo)
                val isAnterior = (rec.ano < anoAlvo) || (rec.ano == anoAlvo && mesRecIndex < mesAlvoIndex)

                if (isAnterior && (rec.parcelasRestantes > 0 || rec.parcelasRestantes == -1)) {
                    val diaOriginal = rec.vencimento.split("/").firstOrNull() ?: "01"
                    val mesIndex = meses.indexOf(mesAlvo)
                    val novoVencimento = String.format(Locale.getDefault(), "%s/%02d", diaOriginal, mesIndex + 1)
                    val nova = rec.copy(id = 0, mes = mesAlvo, ano = anoAlvo, vencimento = novoVencimento, status = false, isRecorrente = true, parcelasRestantes = if (rec.parcelasRestantes > 0) rec.parcelasRestantes - 1 else -1, parcelasTotais = rec.parcelasTotais)
                    db.utilizadorDao().inserirTransacao(nova)
                }
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(
            this,
            object : androidx.activity.OnBackPressedCallback(enabled = true) {
                override fun handleOnBackPressed() {
                    if (binding.drawerLayout.isDrawerOpen(androidx.core.view.GravityCompat.START)) {
                        binding.drawerLayout.closeDrawer(androidx.core.view.GravityCompat.START)
                    } else {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                    }
                }
            },
        )
    }
}
