package com.example.formacao

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.enableEdgeToEdge
import androidx.core.content.edit
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import com.example.formacao.database.MinhaBaseDados
import com.example.formacao.databinding.ActivityRegistoBinding
import com.example.formacao.models.Transacao
import com.example.formacao.models.Utilizador
import com.example.formacao.utils.showToast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar
import java.util.Locale

class RegistoActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRegistoBinding

    companion object {
        private const val PREFS_NAME = "FinlyAppPrefs"
        private const val KEY_EMAIL = "EMAIL"
    }

    private var isEditMode = false
    private var isUserEditMode = false
    private var transacaoId = 0
    private var itemOriginal: String? = null
    private var userId = 0
    private var isNewUserRegistration = false
    private var fotoUriStr: String? = null

    private val meses = arrayOf("Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro")
    private val categorias = arrayOf(
        "Geral", 
        "Habitação", 
        "Alimentação", 
        "Transporte", 
        "Saúde", 
        "Lazer", 
        "Educação", 
        "Compras", 
        "Assinaturas", 
        "Investimentos", 
        "Poupança", 
        "Exterior",
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityRegistoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isNewUserRegistration = intent.getBooleanExtra("isNewUser", false)
        isEditMode = intent.getBooleanExtra("isEditTransaction", false)
        isUserEditMode = intent.getBooleanExtra("isUserEdit", false)

        configurarSpinners()

        binding.cbRepetirSempre.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                binding.cbRepetirVezes.isChecked = false
                binding.parcelasLayout.visibility = View.GONE
            }
        }

        binding.cbRepetirVezes.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                binding.cbRepetirSempre.isChecked = false
                binding.parcelasLayout.visibility = View.VISIBLE
                // Dar deslocamento (scroll) para o campo novo
                binding.root.post {
                    binding.root.smoothScrollTo(0, binding.parcelasLayout.bottom)
                }
            } else {
                binding.parcelasLayout.visibility = View.GONE
            }
        }

        if (isNewUserRegistration) {
            configurarParaNovoUtilizador()
        } else if (isUserEditMode) {
            configurarParaEdicaoUtilizador()
        } else {
            configurarParaTransacao()
            if (isEditMode) configurarParaEdicaoTransacao()
        }

        binding.btnFinalizarRegisto.setOnClickListener {
            when {
                isNewUserRegistration -> registarNovoUtilizador()
                isUserEditMode -> guardarEdicaoUtilizador()
                else -> guardarTransacao()
            }
        }

        // Ocultar teclado ao clicar fora
        binding.root.setOnClickListener { esconderTeclado() }

        // Ajustar Insets para o conteúdo não ser cortado pelo topo ou botões
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            
            // Adiciona padding no topo para o título baixar (horas, bateria não taparem)
            binding.root.updatePadding(top = systemBars.top, bottom = systemBars.bottom)
            insets
        }
    }

    private fun esconderTeclado() {
        val view = this.currentFocus
        if (view != null) {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
            view.clearFocus()
        }
    }

    private fun configurarSpinners() {
        val adapterMes = ArrayAdapter(this, android.R.layout.simple_spinner_item, meses)
        adapterMes.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerMesTransacao.adapter = adapterMes

        // 1. Tentar obter o mês passado pela MainActivity (onde o utilizador navegava)
        val mesVindoDaApp = intent.getStringExtra("MES_ATUAL")

        if (mesVindoDaApp != null) {
            val index = meses.indexOf(mesVindoDaApp)
            if (index != -1) binding.spinnerMesTransacao.setSelection(index)
        } else {
            // 2. Fallback: Usar o mês atual do calendário se for o primeiro registo
            val mesCalendario = Calendar.getInstance()[Calendar.MONTH]
            binding.spinnerMesTransacao.setSelection(mesCalendario)
        }

        val adapterCat = ArrayAdapter(this, android.R.layout.simple_spinner_item, categorias)
        adapterCat.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerCategoria.adapter = adapterCat
    }

    private fun configurarParaNovoUtilizador() {
        binding.titleRegisto.text = getString(R.string.criar_nova_conta)
        binding.itemLayout.hint = "Nome Completo"
        binding.valorLayout.hint = "E-mail"
        binding.regEmailText.inputType = android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        binding.dataLayout.hint = "Telemóvel"
        binding.regPhoneText.inputType = android.text.InputType.TYPE_CLASS_PHONE
        binding.regPhoneText.isFocusableInTouchMode = true
        binding.regPhoneText.isFocusable = true
        binding.regPhoneText.setOnClickListener(null) // Remover calendário
        binding.senhaLayout.visibility = View.VISIBLE
        
        // Ocultar tudo o que é de transação (REFORÇADO)
        binding.llSelectors.visibility = View.GONE
        binding.spinnerMesTransacao.visibility = View.GONE
        binding.spinnerCategoria.visibility = View.GONE
        binding.rgTipo.visibility = View.GONE
        binding.llRecorrenciaOpcoes.visibility = View.GONE
        binding.parcelasLayout.visibility = View.GONE
        
        binding.cbRepetirSempre.isChecked = false
        binding.cbRepetirVezes.isChecked = false
        binding.cardFotoPerfil.visibility = View.GONE
        binding.btnFinalizarRegisto.text = getString(R.string.btn_criar_conta)
    }

    private fun configurarParaEdicaoUtilizador() {
        userId = intent.getIntExtra("id", 0)
        binding.titleRegisto.text = getString(R.string.editar_perfil)
        binding.itemLayout.hint = "Nome Completo"
        binding.regNameText.setText(intent.getStringExtra("name"))
        binding.valorLayout.hint = "E-mail"
        binding.regEmailText.setText(intent.getStringExtra("email"))
        
        // CORREÇÃO: Forçar teclado de texto/e-mail para o campo de e-mail no perfil
        binding.regEmailText.inputType = android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        
        binding.dataLayout.hint = "Telemóvel"
        binding.regPhoneText.setText(intent.getStringExtra("phone"))
        binding.regPhoneText.inputType = android.text.InputType.TYPE_CLASS_PHONE
        binding.regPhoneText.isFocusableInTouchMode = true
        binding.regPhoneText.isFocusable = true
        binding.regPhoneText.setOnClickListener(null) // Remover calendário

        binding.senhaLayout.visibility = View.VISIBLE
        binding.regSenhaText.setText(intent.getStringExtra("senha"))

        fotoUriStr = intent.getStringExtra("foto")

        // Ocultar tudo o que é de transação (REFORÇADO)
        binding.llSelectors.visibility = View.GONE
        binding.spinnerMesTransacao.visibility = View.GONE
        binding.spinnerCategoria.visibility = View.GONE
        binding.rgTipo.visibility = View.GONE
        binding.llRecorrenciaOpcoes.visibility = View.GONE
        binding.parcelasLayout.visibility = View.GONE
        
        binding.cbRepetirSempre.isChecked = false
        binding.cbRepetirVezes.isChecked = false
        binding.cardFotoPerfil.visibility = View.GONE
        binding.btnFinalizarRegisto.text = getString(R.string.btn_atualizar_perfil)
    }

    private fun configurarParaTransacao() {
        binding.senhaLayout.visibility = View.GONE
        binding.regPhoneText.setOnClickListener { mostrarCalendario() }
        binding.llRecorrenciaOpcoes.visibility = View.VISIBLE
        
        // Se for uma NOVA transação (não edição), ocultamos o seletor de mês
        if (!isEditMode) {
            binding.spinnerMesTransacao.visibility = View.GONE
            binding.tvLabelMesRegisto.visibility = View.GONE
            
            // Pré-preencher com a data de hoje (ou dia 01 do mês selecionado)
            val cal = Calendar.getInstance()
            val diaAtual = cal[Calendar.DAY_OF_MONTH]
            val mesAtualIndex = cal[Calendar.MONTH]
            val mesAtualNome = meses[mesAtualIndex]
            
            val mesVindoDaApp = intent.getStringExtra("MES_ATUAL") ?: mesAtualNome
            val mesParaData = meses.indexOf(mesVindoDaApp) + 1
            
            binding.regPhoneText.setText(String.format(Locale.getDefault(), "%02d/%02d", diaAtual, mesParaData))
        }
    }

    private fun configurarParaEdicaoTransacao() {
        transacaoId = intent.getIntExtra("id", 0)
        itemOriginal = intent.getStringExtra("item")
        binding.titleRegisto.text = getString(R.string.editar_item)
        binding.regNameText.setText(itemOriginal)
        binding.regEmailText.setText(intent.getDoubleExtra("valor", 0.0).toString())
        binding.regPhoneText.setText(intent.getStringExtra("vencimento"))

        val tipo = intent.getStringExtra("tipo")
        if (tipo == "RENDA") binding.rbRenda.isChecked = true else binding.rbDespesa.isChecked = true

        // Se for edição, também carregamos o mês guardado na transação
        val mesSalvo = intent.getStringExtra("mes")
        if (mesSalvo != null) {
            val index = meses.indexOf(mesSalvo)
            if (index != -1) binding.spinnerMesTransacao.setSelection(index)
        }

        // Carregar categoria
        val catSalva = intent.getStringExtra("categoria")
        if (catSalva != null) {
            val index = categorias.indexOf(catSalva)
            if (index != -1) binding.spinnerCategoria.setSelection(index)
        }

        // Carregar estado de recorrência
        val isRec = intent.getBooleanExtra("isRecorrente", false)
        val tot = intent.getIntExtra("parcelasTotais", 0)

        if (isRec) {
            if (tot == -1) {
                binding.cbRepetirSempre.isChecked = true
            } else if (tot > 0) {
                binding.cbRepetirVezes.isChecked = true
                binding.etParcelas.setText(tot.toString())
                binding.parcelasLayout.visibility = View.VISIBLE
            }
        }

        binding.btnFinalizarRegisto.text = getString(R.string.atualizar_item)
    }

    private fun mostrarCalendario() {
        esconderTeclado()
        val c = Calendar.getInstance()
        val dpd = DatePickerDialog(
            this,
            { _, _, month, day ->
                binding.regPhoneText.setText(String.format(Locale.getDefault(), "%02d/%02d", day, month + 1))
            },
            c[Calendar.YEAR],
            c[Calendar.MONTH],
            c[Calendar.DAY_OF_MONTH],
        )
        dpd.show()
    }

    private fun guardarTransacao() {
        val item = binding.regNameText.text.toString().trim()
        val valorStr = binding.regEmailText.text.toString().trim()
        var venc = binding.regPhoneText.text.toString().trim()
        val tipo = if (binding.rbRenda.isChecked) "RENDA" else "DESPESA"
        val categoria = binding.spinnerCategoria.selectedItem.toString()
        val mes = binding.spinnerMesTransacao.selectedItem.toString()

        if (item.isEmpty() || valorStr.isEmpty() || venc.isEmpty()) {
            showToast("Introduza a descrição, o valor e a data")
            return
        }

        // Se o utilizador colocou apenas o dia (ex: "15"), completamos com o mês
        if (!venc.contains("/")) {
            val diaInt = venc.toIntOrNull()
            if ((diaInt != null) && (diaInt in 1..31)) {
                val mesIndex = meses.indexOf(mes) + 1
                venc = String.format(Locale.getDefault(), "%02d/%02d", diaInt, mesIndex)
            } else {
                showToast("Data inválida. Use o formato DD/MM")
                return
            }
        }

        val isSempre = binding.cbRepetirSempre.isChecked
        val isVezes = binding.cbRepetirVezes.isChecked
        val inputParcelas = binding.etParcelas.text.toString().toIntOrNull() ?: 1

        val isRecorrente = isSempre || isVezes
        val numParcelas = when {
            isSempre -> -1
            isVezes -> if (inputParcelas > 0) inputParcelas else 0
            else -> 0
        }

        val valor = valorStr.toDoubleOrNull() ?: 0.0
        val email = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).getString(KEY_EMAIL, "CONVIDADO") ?: "CONVIDADO"

        val anoIntent = if (isEditMode) {
            intent.getIntExtra("ano", Calendar.getInstance()[Calendar.YEAR])
        } else {
            intent.getIntExtra("ANO_ATUAL", Calendar.getInstance()[Calendar.YEAR])
        }

        executarGravacao(item, valor, venc, tipo, categoria, mes, email, isRecorrente, numParcelas, anoIntent)
    }

    private fun executarGravacao(item: String, valor: Double, venc: String, tipo: String, cat: String, mes: String, dono: String, isRec: Boolean, numParcelas: Int, ano: Int) {
        lifecycleScope.launch(Dispatchers.IO) {
            val db = MinhaBaseDados.getDatabase(this@RegistoActivity)
            val transacao = Transacao(
                id = if (isEditMode) transacaoId else 0,
                item = item, valor = valor, vencimento = venc,
                tipo = tipo, categoria = cat, mes = mes,
                ano = ano,
                donoEmail = dono,
                status = intent.getBooleanExtra("status", false),
                isRecorrente = isRec,
                parcelasRestantes = when {
                    numParcelas > 0 -> numParcelas - 1
                    numParcelas == -1 -> -1
                    else -> 0
                },
                parcelasTotais = numParcelas,
            )

            if (isEditMode) {
                db.utilizadorDao().atualizarTransacao(transacao)
                
                // Se for recorrente, atualizar também as parcelas FUTURAS se existirem
                if (isRec) {
                    val todasDoDono = db.utilizadorDao().obterTransacoesPorDono(dono)
                    val mesIndexAtual = meses.indexOf(mes)
                    
                    todasDoDono.filter { 
                        (it.item == (itemOriginal ?: item)) && 
                        ((it.ano > ano) || ((it.ano == ano) && (meses.indexOf(it.mes) > mesIndexAtual)))
                    }.forEach { futura ->
                        // Atualiza tanto o valor quanto o nome (caso tenha mudado)
                        db.utilizadorDao().atualizarTransacao(futura.copy(item = item, valor = valor))
                    }
                }
            } else {
                db.utilizadorDao().inserirTransacao(transacao)
            }

            withContext(Dispatchers.Main) {
                showToast("Dados guardados!")
                finish()
            }
        }
    }

    private fun registarNovoUtilizador() {
        val nome = binding.regNameText.text.toString().trim()
        val email = binding.regEmailText.text.toString().trim()
        val phone = binding.regPhoneText.text.toString().trim()
        val senha = binding.regSenhaText.text.toString().trim()

        if (nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
            showToast("Introduza todos os campos obrigatórios")
            return
        }

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val db = MinhaBaseDados.getDatabase(this@RegistoActivity)
                db.utilizadorDao().insertUtilizador(Utilizador(
                    nome = nome, email = email, telemovel = phone, donoEmail = "SISTEMA", senha = senha, fotoUri = fotoUriStr,
                ))
                withContext(Dispatchers.Main) {
                getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit { putString("TEMP_EMAIL", email) }
                    showToast("Conta criada!", isLong = true)
                    finish()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    showToast("Erro: ${e.message}", isLong = true)
                }
            }
        }
    }

    private fun guardarEdicaoUtilizador() {
        val nome = binding.regNameText.text.toString().trim()
        val email = binding.regEmailText.text.toString().trim()
        val phone = binding.regPhoneText.text.toString().trim()
        val senha = binding.regSenhaText.text.toString().trim()

        if (nome.isEmpty() || email.isEmpty()) {
            showToast("Nome e E-mail são obrigatórios")
            return
        }

        lifecycleScope.launch(Dispatchers.IO) {
            val db = MinhaBaseDados.getDatabase(this@RegistoActivity)
            val utilizadorEditado = Utilizador(
                id = userId,
                nome = nome,
                email = email,
                telemovel = phone,
                donoEmail = "SISTEMA",
                senha = senha,
                fotoUri = fotoUriStr,
            )
            db.utilizadorDao().atualizarUtilizador(utilizadorEditado)

            val sharedPref = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
            val emailLembradoAntigo = sharedPref.getString("EMAIL_LEMBRADO", "")

            sharedPref.edit {
                putString("NAME", nome)
                putString(KEY_EMAIL, email)
                // Se o e-mail que estava lembrado no login for o mesmo que estamos a editar, atualizamos também
                if (!emailLembradoAntigo.isNullOrEmpty()) {
                    putString("EMAIL_LEMBRADO", email)
                }
            }

            withContext(Dispatchers.Main) {
                showToast("Perfil atualizado!")
                finish()
            }
        }
    }
}
